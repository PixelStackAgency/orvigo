<?php
// --- public/service-ac.php ---
$serviceKey = 'ac';
$serviceTitle = 'AC Service & Repair';
include __DIR__ . '/service-template.php';
