<?php
// --- public/service-geyser.php ---
$serviceKey = 'geyser';
$serviceTitle = 'Geyser / Water Heater Repair';
include __DIR__ . '/service-template.php';
