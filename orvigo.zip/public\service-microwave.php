<?php
// --- public/service-microwave.php ---
$serviceKey = 'microwave';
$serviceTitle = 'Microwave Oven Repair';
include __DIR__ . '/service-template.php';
