<?php
// --- public/service-mobile-tablet.php ---
$serviceKey = 'mobile_tablet';
$serviceTitle = 'Mobile & Tablet Repair';
include __DIR__ . '/service-template.php';
