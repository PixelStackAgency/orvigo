<?php
// --- public/service-refrigerator.php ---
$serviceKey = 'refrigerator';
$serviceTitle = 'Refrigerator Repair';
include __DIR__ . '/service-template.php';
