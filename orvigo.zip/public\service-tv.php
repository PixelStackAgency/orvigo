<?php
// --- public/service-tv.php ---
$serviceKey = 'tv';
$serviceTitle = 'Television Repair';
include __DIR__ . '/service-template.php';
