<?php
// --- public/service-washing-machine.php ---
$serviceKey = 'washing_machine';
$serviceTitle = 'Washing Machine Repair';
include __DIR__ . '/service-template.php';
