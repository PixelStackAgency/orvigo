<?php
// --- public/service-water-purifier.php ---
$serviceKey = 'water_purifier';
$serviceTitle = 'Water Purifier Service & Repair';
include __DIR__ . '/service-template.php';
